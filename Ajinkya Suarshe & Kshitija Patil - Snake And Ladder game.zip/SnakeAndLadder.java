package miniproject;
import java.util.*;
import java.util.Scanner;
public class SnakeAndLadder 
{
    int flag = 0;
    void snakeGame() 
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("WELCOME TO SNAKES AND LADDERS");
        System.out.println("===================================================================================");      
        System.out.println("There are snakes on 17,54,64,87,93");
        System.out.println("There are ladders on 4,16,35,50,57,68 and 86");
        System.out.println("Enter to start the game...");
        sc.nextLine();
        System.out.println("Game Started");
        Random r=new Random();
        int snakes[][]={{17, 8},{54, 28},{64, 20},{87, 75},{93, 83}};
        int ladders[][]={{4, 14},{16, 82},{57, 79},{68, 85},{35, 78},{50, 60},{86,92}};
        int Ajinkya=1, Kshitija=1;
        int turn1=1,turn2=2;
        while((Ajinkya!=100)||(Kshitija!=100))
        {
            if(flag==0){
            System.out.println("---------Player1-----------");    
            System.out.println("Ajinkya,presss r to roll the die...");
            turn1++;
            sc.nextLine();
            int diceroll=r.nextInt(7);
            if(diceroll==0)           
            {
               diceroll++;
            }
            System.out.println("The number on the die is "+diceroll);
            if((Ajinkya+diceroll)>100)
            {
                System.out.println("You will have to wait for the next turn, you have exceeded 100.");
                flag=1;
            }
            else if((Ajinkya+diceroll)==100)
            {
                System.out.println("Congratulations Ajinkya, you have won the game!");
                break;
            }
            else
            {
                Ajinkya+=diceroll;
                System.out.println("Your new position is "+Ajinkya+".");             
                
                switch(Ajinkya)
                {
                    case 4  : System.out.println("You got the ladder on 4! Your new position is 14.");
                              Ajinkya=14;
                              break;
                    case 16 : System.out.println("You got the ladder on square 16! Your new position is 82.");
                              Ajinkya=82;
                              break;
                    case 17 : System.out.println("You were caught by the snake at square 17. You're now down to square 8.");
                              Ajinkya=8;
                              break;
                    case 35 : System.out.println("You got the ladder at square 35! Your new position is 78.");
                              Ajinkya=78;
                              break;
                    case 50 : System.out.println("You got the ladder at square 50! Your new position is 60.");
                              Ajinkya=60;
                              break;
                    case 54 : System.out.println("You were caught by the snake at square 54! You're now down to square 28.");
                              Ajinkya=28;
                              break;    
                    case 57 : System.out.println("You got the ladder on square 57! Your new position is 79.");
                              Ajinkya=79;
                              break;                  
                    case 64 : System.out.println("You were caught by the snake at square 64! You're now down to square 40.");    
                              Ajinkya=40;
                              break;
                    case 68 : System.out.println("You got the ladder on square 68! Your new position is 85.");
                              Ajinkya=85;
                              break;                  
                    case 86 : System.out.println("You got the ladder on square 86! Your new position is 92.");
                              Ajinkya=92;
                              break;
                    case 87 : System.out.println("You were caught by the snake at square 87! You're now down to square 75.");
                              Ajinkya=75;
                              break;
                    case 93 : System.out.println("You were caught by the snake at square 93! You're now down to square 83.");
                              Ajinkya=83;
                              break;
                    default : System.out.println("No snakes or ladders here.");       
                }
            }
             if(flag==1 || flag==0){
                System.out.println();
                System.out.println("---------Player2-----------"); 
                System.out.println("Kshitija,press r to roll the die...");
                turn2++;                
                sc.nextLine();
                diceroll=r.nextInt(7);
                if(diceroll==0)
                {
                    diceroll++;
                    flag=0;
                }
                System.out.println("The number on the die is "+diceroll);
                if((Kshitija+diceroll)>100)
                {
                   System.out.println("You will have to wait for the next turn, you have exceeded 100.");                 
                }
                else if((Kshitija+diceroll)==100)
                {
                    System.out.println("Congratulations Kshitija, you have won the game!");
                    break;
                }
                else
                {
                    Kshitija+=diceroll;
                    System.out.println("Your new position is "+Kshitija+".");
               
               
                    switch(Kshitija)
                    {
                        case 4  : System.out.println("You got the ladder on square 4! Your new position is 14.");
                                  Kshitija=14;
                                  break;
                        case 16 : System.out.println("You got the ladder on square 16! Your new position is 82.");
                                  Kshitija=82;
                                  break;
                        case 17 : System.out.println("You were caught by the snake at square 17. You're now down to square 8.");
                                  Kshitija=8;
                                  break;
                        case 35 : System.out.println("You got the ladder at square 35! Your new position is 78.");
                                  Kshitija=78;
                                  break;
                        case 50 : System.out.println("You got the ladder at square 50! Your new position is 60.");
                                  Kshitija=60;
                                  break;
                        case 54 : System.out.println("You were caught by the snake at square 54! You're now down to square 28.");
                                  Kshitija=28;
                                  break;    
                        case 57 : System.out.println("You got the ladder on square 57! Your new position is 79.");
                                  Kshitija=79;
                                  break;                  
                        case 64 : System.out.println("You were caught by the snake at square 64! You're now down to square 40.");    
                                  Kshitija=40;
                                  break;
                        case 68 : System.out.println("You got the ladder on square 68! Your new position is 85.");
                                  Kshitija=85;
                                  break;                       
                        case 86 : System.out.println("You got the ladder on square 86! Your new position is 92.");
                                  Kshitija=92;
                                  break;
                        case 87 : System.out.println("You were caught by the snake at square 87! You're now down to square 75.");
                                  Kshitija=75;
                                  break;
                        case 93 : System.out.println("You were caught by the snake at square 93! You're now down to square 83.");
                                  Kshitija=83;
                                  break;                      
                        default : System.out.println("No snakes or ladders here.");       
                    }
                    }
                }
             
            }
            turn1++;
            turn2++;
        }
         
    }
    public static void main(String[]args) 
    {
        SnakeAndLadder s = new SnakeAndLadder();
        s.snakeGame();
    }
}